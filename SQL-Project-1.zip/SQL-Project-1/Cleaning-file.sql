/*

Cleaning Data in SQL Queries

*/


-- View the whole dataset
select * from wfp_food_prices_per;

/*

Report on the state of the dataset(Cleaniness):
After viewing the dataset, we found;
1. Duplicate case -  the header containing field names was duplicated
2. Wrong Data type assignment -  The following fieldnames were found to be formatted in the wrong data types
   - date
   - latitude
   - longitude
   - price
   - usdprice
3. String value case conversion (market field)
*/

-- Following our Research Questions/Project Objectives,
--  we need to work with relevant data, thus lets drop all columns that are irrelevant in our case

ALTER TABLE wfp_food_prices_per
DROP COLUMN unit,
DROP COLUMN priceflag,
DROP COLUMN pricetype,
DROP COLUMN currency;



-- 1. Duplicate case -  the header containing field names was duplicated

-- delete the duplicate header column
delete from wfp_food_prices_per
where date = '#date';

-- Renaming wrong named columns
-- Rename column from 'date' to date_recorded
ALTER TABLE wfp_food_prices_per
RENAME COLUMN  `date` TO `date_recorded`;


/*

2. Wrong Data type assignment -  The following fieldnames were found to be formatted in the wrong data types
   - date
   - latitude
   - longitude
   - price
   - usdprice

*/


-- 1. Date column

-- We create a new column date_Converted and populate with correct date types from date_recorded
ALTER TABLE wfp_food_prices_per
Add date_Converted Date;

-- update new column with old column values - date_added
UPDATE wfp_food_prices_per 
SET date_Converted = STR_TO_DATE(date_recorded, '%Y-%c-%d');

-- drop old column - date_added
ALTER TABLE wfp_food_prices_per
DROP COLUMN date_recorded;

--  check your new dataset
select * from wfp_food_prices_per;


-- 2. latitude column

-- CASE ONE - FAILS
-- convert latitude column from text to float

UPDATE wfp_food_prices_per
SET latitude = CAST(latitude AS FLOAT);

-- CASE TWO - SUCCEEDS
-- convert latitude column from text to float
ALTER TABLE wfp_food_prices_per ADD latitudeConverted float8;

UPDATE wfp_food_prices_per
SET latitudeConverted = CAST(latitude AS FLOAT);

ALTER TABLE wfp_food_prices_per 
DROP COLUMN latitude;

ALTER TABLE wfp_food_prices_per
CHANGE latitudeConverted latitude float8;

select * from wfp_food_prices_per;




-- 3. longitude column

-- CASE ONE - FAILS
-- convert longitude column from text to float

UPDATE wfp_food_prices_per
SET longitude = CAST(longitude AS FLOAT);

-- CASE TWO - SUCCEEDS
-- convert latitude column from text to float
ALTER TABLE wfp_food_prices_per ADD longitudeConverted float8;

UPDATE wfp_food_prices_per
SET longitudeConverted = CAST(longitude AS FLOAT);

ALTER TABLE wfp_food_prices_per 
DROP COLUMN longitude;

ALTER TABLE wfp_food_prices_per
CHANGE longitudeConverted longitude float8;

select * from wfp_food_prices_per;





-- 4. price column

-- CASE ONE - FAILS
-- convert price column from text to float

UPDATE wfp_food_prices_per
SET price = CAST(price AS FLOAT);


-- CASE TWO - SUCCEEDS
-- convert latitude column from text to float
ALTER TABLE wfp_food_prices_per ADD priceConverted float8;

UPDATE wfp_food_prices_per
SET priceConverted = CAST(price AS FLOAT);

ALTER TABLE wfp_food_prices_per 
DROP COLUMN price;

ALTER TABLE wfp_food_prices_per
CHANGE priceConverted price float8;

select * from wfp_food_prices_per;





-- 5. usdprice column

-- CASE ONE - FAILS
-- convert usdprice column from text to float

UPDATE wfp_food_prices_per
SET usdprice = CAST(usdprice AS FLOAT);

-- CASE TWO - SUCCEEDS
-- convert usdprice column from text to float
ALTER TABLE wfp_food_prices_per ADD usdpriceConverted float8;

UPDATE wfp_food_prices_per
SET usdpriceConverted = CAST(usdprice AS FLOAT);

ALTER TABLE wfp_food_prices_per 
DROP COLUMN usdprice;

ALTER TABLE wfp_food_prices_per
CHANGE usdpriceConverted usdprice float8;

select * from wfp_food_prices_per;


-- 3. String value case conversion (market field names)
UPDATE wfp_food_prices_per
SET market = UPPER(market);

-- =================================== CLEANING DONE ===========================================
