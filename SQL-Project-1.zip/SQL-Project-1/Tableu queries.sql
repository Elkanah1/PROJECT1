/*

Queries used for Tableau Project
OR
SQL Data Exploration
*/

-- Project Objectives/Research Questions
-- 1.	Analyze the trends and patterns of food prices in Peru over time.

-- Lets first get the complete overview of the data, which you can use to identify trends and patterns.
SELECT * FROM wfp_food_prices_per;

-- This will allow you to analyze the trends and patterns of food prices in Peru over time.
SELECT price, YEAR(date_Converted) AS 'the_year'
FROM wfp_food_prices_per
GROUP BY price, YEAR(date_Converted);

-- OR
SELECT AVG(price) AS average_price, YEAR(date_Converted) AS 'the_year'
FROM wfp_food_prices_per
GROUP BY YEAR(date_Converted);


-- 2.	Identify the factors influencing food prices in different regions of Peru.

-- Query 1: This query will SELECT the average price of each commodity in each region of Peru.
SELECT commodity, latitude, longitude, AVG(price) AS avg_price
FROM wfp_food_prices_per
GROUP BY commodity, latitude, longitude;

-- Query 2: This query will SELECT the average price of each commodity in each region of Peru, 
-- and then calculate the standard deviation of the prices.
SELECT commodity, latitude, longitude, AVG(price) AS avg_price, STDDEV(price) AS std_dev
FROM wfp_food_prices_per
GROUP BY commodity, latitude, longitude;

/*

REMARK: 
1. These queries will allow you to identify the commodities that are most expensive in different regions of Peru,
 and the factors that are influencing the prices of these commodities. 
 For example, you might find that the price of rice is higher in the coastal region of Peru than in the Andean region. 
 This could be due to a number of factors, such as the availability of rice in the region, 
 the cost of transportation, or the demand for rice in the region.

2. You could also use these queries to identify the regions of Peru where food prices are most volatile. 
For example, you might find that the standard deviation of the price of rice is higher in the Amazon region 
than in the coastal region. 
This could be due to a number of factors, such as the weather, the availability of rice in the region, 
or the demand for rice in the region.
*/


-- 3.	Compare the prices of different food categories and commodities in Peru.

-- Query 1: This query will SELECT the average price of each food category in Peru.
SELECT category, AVG(price) AS avg_price
FROM wfp_food_prices_per
GROUP BY category;

-- Query 2: This query will SELECT the average price of each commodity in Peru.
SELECT commodity, AVG(price) AS avg_price
FROM wfp_food_prices_per
GROUP BY commodity;

-- Query 3: This query will SELECT the average price of each commodity in each food category in Peru.
SELECT category, commodity, AVG(price) AS avg_price
FROM wfp_food_prices_per
GROUP BY category, commodity;


/*

REMARK: 
1. These queries will allow you to compare the prices of different food categories and commodities in Peru. 
For example, you might find that the average price of rice is higher than the average price of beans in Peru. 
This could be due to a number of factors, such as the availability of rice in Peru, 
the cost of production of rice, or the demand for rice in Peru.

2. You could also use these queries to identify the commodities that are most expensive in Peru, 
and the food categories that are most expensive in Peru. This information could be used to 
inform policy decisions about food security in Peru.
*/


-- 4.	Investigate the relationship between food prices and market locations (admin1 and admin2).

-- Query 1: This query will SELECT the average price of each commodity in each admin1 region in Peru.

SELECT admin1, commodity, AVG(price) AS avg_price
FROM wfp_food_prices_per
GROUP BY admin1, commodity;

-- Query 2: This query will SELECT the average price of each commodity in each admin2 region in Peru.
SELECT admin2, commodity, AVG(price) AS avg_price
FROM wfp_food_prices_per
GROUP BY admin2, commodity;

/*

REMARK: 
1. These queries will allow you to investigate the relationship between food prices and market locations (admin1 and admin2). 
For example, you might find that the average price of rice is higher in the Lima admin1 region than in the Cusco admin1 region. 
This could be due to a number of factors, such as the availability of rice in the Lima admin1 region, 
the cost of production of rice in the Lima admin1 region, or the demand for rice in the Lima admin1 region.

2. You could also use these queries to identify the admin1 regions and admin2 regions where food prices are most expensive,
 and the commodities that are most expensive in these regions.
 This information could be used to inform policy decisions about food security in Peru.
*/


-- 5.	Examine the impact of inflation and currency fluctuations on food prices.
